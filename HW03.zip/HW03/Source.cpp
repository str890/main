#include <string>
#include <iostream>
#include <fstream>
#define HASH_TABLE_SIZE 2503

int insert(std::string input, std::string table[], int &probes);
int hashIndex(std::string input);

int main() {
	std::string hashTable[HASH_TABLE_SIZE];
	std::string fileReadString;
	int numOfKeys = 0;
	int numOfProbes = 0;
	int &probeReference = numOfProbes;

	std::ifstream inFile;
	inFile.open("C:\\Users\\danie\\OneDrive\\Documents\\Data Structures and Algorithms\\HW03\\ReadFile.txt");
	if (!inFile) {
		std::cerr << "Unable to open file";
		exit(1);
	}

	while (inFile >> fileReadString) {
		insert(fileReadString, hashTable, probeReference);
		numOfKeys++;
	}

	std::cout << "Average number of probes: " << (double)numOfProbes / (double)numOfKeys;

	getchar();
	return 0;
}

int insert(std::string input, std::string table[], int &probes) {
	int keyLocation = hashIndex(input);
	int probing = 1;

	while (table[keyLocation] != "" && table[keyLocation] != input) {
		probes++;
		keyLocation = keyLocation + probing * probing;
		keyLocation %= HASH_TABLE_SIZE;

		if (probing == HASH_TABLE_SIZE) {
			std::cout << "Error: hash table full\n\n";
			table[keyLocation] = "";
		}

		probing ++;
	}

	table[keyLocation] = input;
	probes++;

	return keyLocation;
}

int hashIndex(std::string input) {
	int returnKey = 1;

	if (input.length() > 32) {
		std::cout << "Error: maximum input length is 32 characters\n\n";
		return 1;
	}

	for (int i = 0; i < input.length(); i++) {
		returnKey *= input[i];
		returnKey %= HASH_TABLE_SIZE;
	}

	return returnKey;
}
