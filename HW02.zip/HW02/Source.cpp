#include "BTNode.h"
#include "BinaryTree.h"
#include <iostream>

int main() {
	BinaryTree currentTree;
	int temp = 0;
	int temp2 = 0;

	int input = 9;

	while (input != 0) {
		switch (input)
		{
		case 1:
			currentTree.clearTree();
			std::cin >> temp;
			for (int i = 0; i < temp; i++) {
				currentTree.insertNode(new BTNode(rand()%100));
			}
			break;

		case 2:
			currentTree.clearTree();
			std::cin >> temp;
			for (int i = 0; i < temp; i++) {
				std::cin >> temp2;
				currentTree.insertNode(new BTNode(temp2));
			}
			break;

		case 3:
			currentTree.clearTree();
			std::cin >> temp;
			currentTree.fullTree(temp);
			break;

		case 4:
			std::cout << currentTree.treeHeight();
			break;

		case 5:
			std::cout << currentTree.treeWidgh();
			break;

		case 6:
			currentTree.displayPreorder();
			break;

		case 7:
			currentTree.displayLeaves();
			break;

		case 8:
			currentTree.clearTree();
			break;

		case 9:
			std::cout << "1 N: Create N (where N > 0) distinct integers using the random number generator, and insert these N distinct integers into an empty binary search tree. Set the current binary search tree to this binary search tree after the execution of this command. Delete the old tree if it exists.\n\n";
			std::cout << "2 N n1 n2 ... : Insert N (where N > 0) distinct integers (n1, n2, ...) into an empty binary search tree. These integers will be given from the command line. For instance, if the command line includes \" 2 5 6 3 8 1 9 \", your function should insert the integers 6, 3, 8, 1, and 9 into an empty binary search tree in the given order. Note that here 5 is the number of nodes that are to be inserted. Set the current binary search tree to this binary search tree after the execution of this command. Delete the old tree if it exists.\n\n";
			std::cout << "3 H: Create a full binary search tree with a height of H using integers 1, 2, ... 2^H-1.\n\n";
			std::cout << "4: Find and display the height of the current binary search tree.\n\n";
			std::cout << "5: Find and display the width of the current binary search tree.\n\n";
			std::cout << "6: Display tree nodes using preorder traversal.\n\n";
			std::cout << "7: Display all leaves of the current tree in ascending order.\n\n";
			std::cout << "8: Delete the root of the current binary tree.\n";

		default:
			break;
		}

		std::cout << "\nPlease enter a new command (0 to exit, 9 for help): ";
		std::cin >> input;
	}
	
	return 0;
}