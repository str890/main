#pragma once
#include <stddef.h>
#include <iostream>
#include <algorithm>

class BTNode {
public:
	explicit BTNode(const int val) {
		data = val;
		left = NULL;
		right = NULL;
	}

	void setLeft(BTNode* leftPtr) { left = leftPtr; }
	void setRight(BTNode* rightPtr) { right = rightPtr; }
	void setData(const int val) { data = val; }

	BTNode* getLeft() const { return left; }
	BTNode* getRight() const { return right; }
	int getData() { return data; }

	void displayPreorder() {
		std::cout << data << " ";

		if (left != NULL) {
			left->displayPreorder();
		}

		if (right != NULL) {
			right->displayPreorder();
		}
	}

	void displayLeaves() {
		if (left == NULL && right == NULL) {
			std::cout << data << " ";
		}

		if (left != NULL) {
			left->displayLeaves();
		}

		if (right != NULL) {
			right->displayLeaves();
		}
	}

	void insertNode(BTNode* node) {
		if (node->getData() < data) {
			if (left == NULL) {
				left = node;
			}
			else {
				left->insertNode(node);
			}
		}
		else {
			if (right == NULL) {
				right = node;
			}
			else {
				right->insertNode(node);
			}
		}
	}

	void fullTree(int val, int height) {
		insertNode(new BTNode(val - pow(2,height)/4));
		insertNode(new BTNode(val + pow(2,height)/4));
		if (height > 2) {
			fullTree(val - pow(2,height) / 4, height - 1);
			fullTree(val + pow(2,height) / 4, height - 1);
		}
	}

	int treeHeight() {
		if (this == NULL) {
			return 0;
		}
		
		return 1 + std::max(left->treeHeight(), right->treeHeight());
	}

	int treeWidth() {
		int maxWidth = 0;
		for (int currentHeight = 1; currentHeight <= treeHeight(); currentHeight++) {
			maxWidth = std::max(recursiveWidth(currentHeight, 1), maxWidth);
		}
		return maxWidth;
	}

	int recursiveWidth(int currentHeight, int checkHeight) {
		if (this == NULL) {
			return 0;
		}

		if (currentHeight == checkHeight) {
			return 1;
		}

		return left->recursiveWidth(currentHeight, checkHeight+1) + right->recursiveWidth(currentHeight, checkHeight+1);
	}

private:
	int data;
	BTNode* left;
	BTNode* right;
};