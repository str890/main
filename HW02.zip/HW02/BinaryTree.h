#pragma once
class BinaryTree {
public:
	explicit BinaryTree() {
		root = NULL;
	}

	void insertNode(BTNode* node) {
		if (root == NULL) {
			root = node;
		}
		else {
			root->insertNode(node);
		}
	}

	void fullTree(int height) {
		root = new BTNode(pow(2,height)/2);
		root->fullTree(pow(2,height)/2,height);
	}

	int treeHeight() {
		return root->treeHeight();
	}

	int treeWidgh() {
		return root->treeWidth();
	}

	void displayPreorder() {
		if (root == NULL) {
			std::cout << "Current tree is empty\n";
		}
		else {
			root->displayPreorder();
			std::cout << "\n";
		}
	}

	void displayLeaves() {
		if (root == NULL) {
			std::cout << "Current tree is empty\n";
		}
		else {
			root->displayLeaves();
			std::cout << "\n";
		}
	}

	void clearTree() {
		root = NULL;
	}

private:
	BTNode* root;
};